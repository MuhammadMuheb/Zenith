// Phase 1 checks. Start the server first, with no email settings, then run this.
//   SKIP_VITE=1 NODE_ENV=test PORT=3101 DATABASE_PATH=/tmp/z.db npx tsx server/index.ts
//   BASE=http://localhost:3101 node scripts/phase1-check.mjs
import crypto from 'node:crypto';

const BASE = process.env.BASE || 'http://localhost:3101';
let passed = 0, failed = 0;
const ok = (name, cond, extra = '') => {
  if (cond) { passed++; console.log(`PASS  ${name}`); }
  else { failed++; console.log(`FAIL  ${name} ${extra}`); }
};
const dev = () => crypto.randomBytes(16).toString('hex');

async function call(method, path, body, headers = {}) {
  const r = await fetch(BASE + '/api' + path, {
    method,
    headers: { 'content-type': 'application/json', ...headers },
    body: body === undefined ? undefined : JSON.stringify(body),
  });
  let json = {};
  try { json = await r.json(); } catch {}
  return { status: r.status, ...json };
}
const bearer = (t, u) => ({ authorization: `Bearer ${t}`, ...(u ? { 'x-unlock-token': u } : {}) });
async function lastCode(email) {
  const r = await call('GET', `/dev/mailbox?email=${encodeURIComponent(email)}`);
  const m = r.messages?.[0];
  return m ? m.text.match(/\n(\d{6})\n/)?.[1] : undefined;
}
const stamp = Date.now();
const emailA = `a${stamp}@gmail.com`, emailB = `b${stamp}@gmail.com`, emailC = `c${stamp}@gmail.com`, emailD = `d${stamp}@gmail.com`;
const dA = dev(), dB = dev(), dC = dev(), dD = dev();

async function makeAccount(email, deviceId, pin) {
  await call('POST', '/auth/signup', { name: 'Test', email, password: 'secret-pass-1' });
  const v = await call('POST', '/auth/verify', { email, code: await lastCode(email), deviceId });
  const p = await call('POST', '/device/pin', { pin }, bearer(v.token));
  return { token: v.token, unlock: p.unlockToken };
}

// 1. Wrong-looking email and short password are stopped at sign-up
let r = await call('POST', '/auth/signup', { name: 'X', email: 'not-an-email', password: 'secret-pass-1' });
ok('1. badly typed email is stopped', r.status === 400 && /doesn't look right/.test(r.error));
r = await call('POST', '/auth/signup', { name: 'X', email: emailA, password: 'short' });
ok('1b. short password is stopped', r.status === 400);

// 2/3. Real address gets a code; wrong code refused; right code works once
r = await call('POST', '/auth/signup', { name: 'Ayesha', email: emailA, password: 'secret-pass-1' });
ok('2. sign-up sends a code', r.status === 200 && r.ok === true);
const codeA = await lastCode(emailA);
ok('2b. the code has 6 digits', /^\d{6}$/.test(codeA || ''));
const wrong = codeA === '000000' ? '111111' : '000000';
r = await call('POST', '/auth/verify', { email: emailA, code: wrong, deviceId: dA });
ok('3. wrong code is refused', r.status === 400 && r.error === 'That code is wrong' && r.triesLeft === 4);
r = await call('POST', '/auth/verify', { email: emailA, code: codeA, deviceId: dA });
ok('3b. right code opens the account and asks for a PIN', r.status === 200 && r.token && r.needsPin === true);
const tokA = r.token;
r = await call('POST', '/auth/verify', { email: emailA, code: codeA, deviceId: dA });
ok('3c. the same code cannot be used twice', r.status === 400);

// 4. Unknown email never gets a code and cannot pass
await call('POST', '/auth/forgot-password', { email: `nobody${stamp}@gmail.com` });
ok('4. an email with no account gets no code', (await lastCode(`nobody${stamp}@gmail.com`)) === undefined);
r = await call('POST', '/auth/verify', { email: `nobody${stamp}@gmail.com`, code: '123456', deviceId: dB });
ok('4b. and cannot get past the code step', r.status === 400);

// 5. Five wrong codes lock that code
await call('POST', '/auth/signup', { name: 'Bilal', email: emailB, password: 'secret-pass-1' });
const codeB = await lastCode(emailB);
const badB = codeB === '000000' ? '111111' : '000000';
for (let i = 0; i < 5; i++) await call('POST', '/auth/verify', { email: emailB, code: badB, deviceId: dB });
r = await call('POST', '/auth/verify', { email: emailB, code: codeB, deviceId: dB });
ok('5. five wrong codes lock it, even the right one is refused', r.status === 429);

// 6. PIN rules
r = await call('POST', '/device/pin', { pin: '1234' }, bearer(tokA));
ok('6. easy PIN 1234 is refused', r.status === 400);
r = await call('POST', '/device/pin', { pin: '12' }, bearer(tokA));
ok('6b. a PIN with too few digits is refused', r.status === 400);
r = await call('POST', '/device/pin', { pin: '4829' }, bearer(tokA));
ok('6c. a good PIN opens the app', r.status === 200 && !!r.unlockToken);
const unlockA = r.unlockToken;

// 7. Data needs the PIN, and stays private
r = await call('PUT', '/data/zenith_notes_v3', { value: [{ id: 'n1', title: 'Ayesha note' }] }, bearer(tokA));
ok('7. data is refused without the PIN unlock', r.status === 423);
r = await call('PUT', '/data/zenith_notes_v3', { value: [{ id: 'n1', title: 'Ayesha note' }] }, bearer(tokA, unlockA));
ok('7b. data saves after unlock', r.status === 200);
r = await call('PUT', '/data/not_allowed_key', { value: 1 }, bearer(tokA, unlockA));
ok('7c. a key outside the allowed names is refused', r.status === 400);
const accC = await makeAccount(emailC, dC, '4829');
r = await call('GET', '/data', undefined, bearer(accC.token, accC.unlock));
ok('8. a second account starts empty', r.status === 200 && Object.keys(r.data).length === 0);
await call('PUT', '/data/zenith_notes_v3', { value: [{ id: 'c1', title: 'Chaudhry note' }] }, bearer(accC.token, accC.unlock));
r = await call('GET', '/data', undefined, bearer(tokA, unlockA));
ok('8b. the first account never sees the second one\'s data', r.status === 200 && !JSON.stringify(r.data).includes('Chaudhry') && JSON.stringify(r.data).includes('Ayesha'));
r = await call('GET', '/data', undefined, bearer(accC.token, unlockA));
ok('8c. one account\'s unlock key does not open another account', r.status === 423);

// 9. Wrong PINs make the app wait
const accD = await makeAccount(emailD, dD, '7305');
let last;
for (let i = 0; i < 5; i++) last = await call('POST', '/device/unlock', { pin: '1357' }, bearer(accD.token));
ok('9. the fifth wrong PIN starts a wait', last.status === 401 && last.retryAfter > 0);
r = await call('POST', '/device/unlock', { pin: '7305' }, bearer(accD.token));
ok('9b. during the wait even the right PIN is refused', r.status === 429);

// 10. Known device needs only the PIN; a new device needs a code
await call('POST', '/device/lock', undefined, bearer(tokA));
r = await call('GET', '/data', undefined, bearer(tokA, unlockA));
ok('10. after lock, the old unlock key stops working', r.status === 423);
r = await call('POST', '/device/unlock', { pin: '4829' }, bearer(tokA));
ok('10b. the PIN opens it again', r.status === 200 && !!r.unlockToken);
const newDev = dev();
r = await call('POST', '/auth/login', { email: emailA, password: 'secret-pass-1', deviceId: newDev });
ok('11. a new device is asked for a code', r.status === 200 && r.needsCode === true);
const devCode = (await lastCode(emailA));
r = await call('POST', '/auth/verify', { email: emailA, code: devCode === '000000' ? '111111' : '000000', deviceId: newDev });
ok('11b. a wrong code on a new device is refused', r.status === 400);
r = await call('POST', '/auth/verify', { email: emailA, code: devCode, deviceId: newDev });
ok('11c. the right code adds the device and asks for a new PIN', r.status === 200 && r.needsPin === true);
r = await call('POST', '/auth/login', { email: emailA, password: 'wrong-password', deviceId: dA });
ok('12. a wrong password is refused', r.status === 401);
r = await call('POST', '/auth/login', { email: emailA, password: 'secret-pass-1', deviceId: dA });
ok('12b. a known device with the right password goes straight to the PIN', r.status === 200 && r.needsPin === false && !!r.token);

// 13. Log out clears the device
const tmpDev = dev();
await call('POST', '/auth/login', { email: emailA, password: 'secret-pass-1', deviceId: tmpDev });
const tmpCode = await lastCode(emailA);
const tmp = await call('POST', '/auth/verify', { email: emailA, code: tmpCode, deviceId: tmpDev });
await call('POST', '/auth/logout', undefined, bearer(tmp.token));
r = await call('GET', '/me', undefined, bearer(tmp.token));
ok('13. after log out the session is gone', r.status === 401);
r = await call('POST', '/auth/login', { email: emailA, password: 'secret-pass-1', deviceId: tmpDev });
ok('13b. and that device needs a code again', r.needsCode === true);

// 14. Forgot PIN and forgot password
r = await call('POST', '/auth/login', { email: emailA, password: 'secret-pass-1', deviceId: dA });
const sess = r.token;
await call('POST', '/device/forgot-pin', undefined, bearer(sess));
const pinCode = await lastCode(emailA);
r = await call('POST', '/device/reset-pin', { code: pinCode, pin: '1234' }, bearer(sess));
ok('14. forgot PIN will not accept an easy new PIN', r.status === 400);
r = await call('POST', '/device/reset-pin', { code: pinCode, pin: '9051' }, bearer(sess));
ok('14b. forgot PIN with the emailed code sets a new PIN', r.status === 200 && !!r.unlockToken);
await call('POST', '/auth/forgot-password', { email: emailA });
const pwCode = await lastCode(emailA);
r = await call('POST', '/auth/reset-password', { email: emailA, code: pwCode, password: 'brand-new-pass-2' });
ok('14c. forgot password sets a new password', r.status === 200);
r = await call('GET', '/me', undefined, bearer(sess));
ok('14d. old sessions stop working after a password change', r.status === 401);
r = await call('POST', '/auth/login', { email: emailA, password: 'brand-new-pass-2', deviceId: dA });
ok('14e. the new password works', r.status === 200 && !!r.token);

// 15. Delete account
await call('POST', '/account/delete-code', undefined, bearer(accC.token, accC.unlock));
const delCode = await lastCode(emailC);
r = await call('DELETE', '/account', { code: delCode === '000000' ? '111111' : '000000' }, bearer(accC.token, accC.unlock));
ok('15. delete with a wrong code is refused', r.status === 400);
r = await call('DELETE', '/account', { code: delCode }, bearer(accC.token, accC.unlock));
ok('15b. delete with the right code works', r.status === 200);
r = await call('POST', '/auth/login', { email: emailC, password: 'secret-pass-1', deviceId: dC });
ok('15c. the deleted account cannot sign in', r.status === 401);
r = await call('GET', '/data', undefined, bearer(accC.token, accC.unlock));
ok('15d. and its data cannot be reached', r.status === 401);

console.log(`\n${passed} passed, ${failed} failed`);
process.exit(failed ? 1 : 0);
