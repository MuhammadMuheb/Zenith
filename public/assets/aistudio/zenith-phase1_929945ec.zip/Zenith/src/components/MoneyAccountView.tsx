// Temporary Home page for Phase 1. It holds no personal figures.
// Phase 4 replaces it with the real Home, Add sheet and month engine from the blueprint.
import React, { useMemo, useState } from 'react';
import { Plus, Trash2, Check } from 'lucide-react';
import { MonthExpenseItem, MonthlyAccountRecord, PersonDebtRecord } from '../types';

export interface UnifiedTransaction {
  id: string;
  refId: string;
  date: string;
  monthKey: string;
  title: string;
  counterparty?: string;
  category: string;
  flowType: 'inflow' | 'outflow' | 'receivable';
  amount: number;
}

interface MoneyAccountViewProps {
  expenses: MonthExpenseItem[];
  onAddExpense: (item: Omit<MonthExpenseItem, 'id'>) => void;
  onDeleteExpense: (id: string) => void;
  debtRecords: PersonDebtRecord[];
  onAddDebtRecord: (record: Omit<PersonDebtRecord, 'id'>) => void;
  onUpdateDebtRecord: (id: string, updates: Partial<PersonDebtRecord>) => void;
  onDeleteDebtRecord: (id: string) => void;
  monthlyAccounts: MonthlyAccountRecord[];
  activeCurrency?: string;
  currencyRates?: Record<string, number>;
}

const today = () => new Date().toISOString().slice(0, 10);
const fmt = (n: number) => Math.round(n).toLocaleString('en-PK');
const field =
  'w-full rounded-lg border border-neutral-700 bg-neutral-900 px-3 py-2 text-sm text-neutral-100 placeholder-neutral-500 outline-none focus:border-emerald-400';
const button =
  'inline-flex items-center justify-center gap-1.5 rounded-lg bg-emerald-400 px-4 py-2 text-sm font-semibold text-neutral-950 hover:bg-emerald-300 disabled:opacity-50';

export const MoneyAccountView: React.FC<MoneyAccountViewProps> = ({
  expenses, onAddExpense, onDeleteExpense, debtRecords, onAddDebtRecord, onUpdateDebtRecord, onDeleteDebtRecord,
}) => {
  const [title, setTitle] = useState('');
  const [amount, setAmount] = useState('');
  const [category, setCategory] = useState('');
  const [date, setDate] = useState(today());
  const [person, setPerson] = useState('');
  const [loanAmount, setLoanAmount] = useState('');
  const [loanDate, setLoanDate] = useState(today());
  const [returnDate, setReturnDate] = useState('');

  const monthName = new Date().toLocaleString('en-US', { month: 'long', year: 'numeric' });

  const spent = useMemo(
    () => expenses.filter((e) => e.monthPeriod === 'current').reduce((s, e) => s + e.amount, 0),
    [expenses]
  );
  const toGetBack = useMemo(
    () => debtRecords.filter((d) => d.type === 'given_udhaar' && d.status !== 'cleared')
      .reduce((s, d) => s + (d.amount - d.returnedAmount), 0),
    [debtRecords]
  );
  const toReturn = useMemo(
    () => debtRecords.filter((d) => d.type === 'taken_borrowed' && d.status !== 'cleared')
      .reduce((s, d) => s + (d.amount - d.returnedAmount), 0),
    [debtRecords]
  );

  const addExpense = () => {
    const n = Number(amount);
    if (!title.trim() || !(n > 0)) return;
    onAddExpense({ title: title.trim(), amount: n, category: category.trim() || 'General', monthPeriod: 'current', date });
    setTitle(''); setAmount(''); setCategory('');
  };

  const addLoan = () => {
    const n = Number(loanAmount);
    if (!person.trim() || !(n > 0)) return;
    onAddDebtRecord({
      personName: person.trim(), amount: n, type: 'given_udhaar', dateGiven: loanDate,
      expectedReturnDate: returnDate || undefined, returnedAmount: 0, status: 'pending', monthPeriod: 'Current Month',
    });
    setPerson(''); setLoanAmount(''); setReturnDate('');
  };

  const card = 'rounded-2xl border border-neutral-800 bg-neutral-900 p-4';
  const recent = [...expenses].sort((a, b) => b.date.localeCompare(a.date)).slice(0, 10);

  return (
    <div className="space-y-6">
      <div>
        <h2 className="text-2xl font-semibold text-white">Home</h2>
        <p className="text-sm text-neutral-400">{monthName}</p>
      </div>

      <div className="grid grid-cols-1 gap-3 sm:grid-cols-3">
        <div className={card}><div className="text-sm text-neutral-400">Spent</div><div className="text-2xl font-semibold text-white">{fmt(spent)}</div></div>
        <div className={card}><div className="text-sm text-neutral-400">To get back</div><div className="text-2xl font-semibold text-emerald-400">{fmt(toGetBack)}</div></div>
        <div className={card}><div className="text-sm text-neutral-400">To return</div><div className="text-2xl font-semibold text-rose-400">{fmt(toReturn)}</div></div>
      </div>

      {expenses.length === 0 && debtRecords.length === 0 && (
        <div className={`${card} text-neutral-300`}>Nothing here yet. Add your first expense or loan below.</div>
      )}

      <div className="grid grid-cols-1 gap-4 lg:grid-cols-2">
        <div className={`${card} space-y-2`}>
          <h3 className="font-semibold text-white">Add an expense</h3>
          <input className={field} placeholder="What for" value={title} onChange={(e) => setTitle(e.target.value)} />
          <div className="grid grid-cols-2 gap-2">
            <input className={field} placeholder="Amount" inputMode="decimal" value={amount} onChange={(e) => setAmount(e.target.value)} />
            <input className={field} placeholder="Group (food, rent...)" value={category} onChange={(e) => setCategory(e.target.value)} />
          </div>
          <input className={field} type="date" value={date} onChange={(e) => setDate(e.target.value)} />
          <button className={button} onClick={addExpense}><Plus className="h-4 w-4" />Add</button>
        </div>

        <div className={`${card} space-y-2`}>
          <h3 className="font-semibold text-white">I lent money</h3>
          <input className={field} placeholder="Name" value={person} onChange={(e) => setPerson(e.target.value)} />
          <input className={field} placeholder="Amount" inputMode="decimal" value={loanAmount} onChange={(e) => setLoanAmount(e.target.value)} />
          <div className="grid grid-cols-2 gap-2">
            <label className="text-xs text-neutral-400">Given on<input className={field} type="date" value={loanDate} onChange={(e) => setLoanDate(e.target.value)} /></label>
            <label className="text-xs text-neutral-400">Remind me on<input className={field} type="date" value={returnDate} onChange={(e) => setReturnDate(e.target.value)} /></label>
          </div>
          <button className={button} onClick={addLoan}><Plus className="h-4 w-4" />Add</button>
        </div>
      </div>

      {recent.length > 0 && (
        <div className={card}>
          <h3 className="mb-2 font-semibold text-white">Recent</h3>
          <ul className="divide-y divide-neutral-800">
            {recent.map((e) => (
              <li key={e.id} className="flex items-center justify-between gap-3 py-2 text-sm">
                <span className="min-w-0 truncate text-neutral-200">{e.title} <span className="text-neutral-500">· {e.category} · {e.date}</span></span>
                <span className="flex items-center gap-3">
                  <span className="text-white">{fmt(e.amount)}</span>
                  <button aria-label="Delete" className="text-neutral-500 hover:text-rose-400" onClick={() => onDeleteExpense(e.id)}><Trash2 className="h-4 w-4" /></button>
                </span>
              </li>
            ))}
          </ul>
        </div>
      )}

      {debtRecords.length > 0 && (
        <div className={card}>
          <h3 className="mb-2 font-semibold text-white">Loans</h3>
          <ul className="divide-y divide-neutral-800">
            {debtRecords.map((d) => (
              <li key={d.id} className="flex items-center justify-between gap-3 py-2 text-sm">
                <span className="min-w-0 truncate text-neutral-200">
                  {d.personName} <span className="text-neutral-500">· {d.dateGiven}{d.expectedReturnDate ? ` · back on ${d.expectedReturnDate}` : ''}</span>
                </span>
                <span className="flex items-center gap-3">
                  <span className={d.status === 'cleared' ? 'text-neutral-500 line-through' : 'text-white'}>{fmt(d.amount)}</span>
                  {d.status !== 'cleared' && (
                    <button aria-label="Received" title="Received" className="text-neutral-500 hover:text-emerald-400"
                      onClick={() => onUpdateDebtRecord(d.id, { status: 'cleared', returnedAmount: d.amount })}><Check className="h-4 w-4" /></button>
                  )}
                  <button aria-label="Delete" className="text-neutral-500 hover:text-rose-400" onClick={() => onDeleteDebtRecord(d.id)}><Trash2 className="h-4 w-4" /></button>
                </span>
              </li>
            ))}
          </ul>
        </div>
      )}
    </div>
  );
};
