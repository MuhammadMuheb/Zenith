import React, { useCallback, useEffect, useRef, useState } from 'react';
import { Loader2, Lock, Mail, ShieldCheck } from 'lucide-react';
import { api, ApiError, hasSession } from '../services/api';
import { clearStorage, flushStorage, hydrateStorage, setSaveErrorHandler } from '../services/storage';

type Screen =
  | 'loading' | 'signup' | 'login' | 'code' | 'makepin' | 'unlock'
  | 'forgot-password' | 'reset-password' | 'forgot-pin' | 'app';

const input =
  'w-full rounded-xl border border-neutral-700 bg-neutral-900 px-4 py-3 text-base text-neutral-100 placeholder-neutral-500 outline-none focus:border-emerald-400';
const primary =
  'w-full rounded-xl bg-emerald-400 px-4 py-3 text-base font-semibold text-neutral-950 transition hover:bg-emerald-300 disabled:opacity-50';
const link = 'text-sm text-emerald-400 hover:text-emerald-300 disabled:opacity-50';

function Shell({ title, note, children }: { title: string; note?: string; children: React.ReactNode }) {
  return (
    <div className="flex min-h-screen items-center justify-center bg-neutral-950 px-4 py-10 text-neutral-100">
      <div className="w-full max-w-sm">
        <div className="mb-6 flex items-center gap-2 text-emerald-400">
          <ShieldCheck className="h-6 w-6" />
          <span className="text-lg font-semibold tracking-tight">Zenith</span>
        </div>
        <h1 className="text-2xl font-semibold">{title}</h1>
        {note && <p className="mt-2 text-sm text-neutral-400">{note}</p>}
        <div className="mt-6 space-y-3">{children}</div>
      </div>
    </div>
  );
}

function Message({ text }: { text: string }) {
  return text ? <p role="alert" className="text-sm text-rose-400">{text}</p> : null;
}

function useCountdown() {
  const [left, setLeft] = useState(0);
  useEffect(() => {
    if (left <= 0) return;
    const t = window.setTimeout(() => setLeft((n) => n - 1), 1000);
    return () => window.clearTimeout(t);
  }, [left]);
  return [left, setLeft] as const;
}

const messageOf = (e: unknown) => (e instanceof ApiError ? e.message : 'Something went wrong');

interface Props {
  children: (controls: { onLock: () => void }) => React.ReactNode;
}

export const AuthGate: React.FC<Props> = ({ children }) => {
  const [screen, setScreen] = useState<Screen>(hasSession() ? 'loading' : 'signup');
  const [error, setError] = useState('');
  const [busy, setBusy] = useState(false);
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [code, setCode] = useState('');
  const [pin, setPin] = useState('');
  const [pin2, setPin2] = useState('');
  const [codeKind, setCodeKind] = useState<'signup' | 'device'>('signup');
  const [wait, setWait] = useCountdown();
  const [pinWait, setPinWait] = useCountdown();
  const locking = useRef(false);

  const go = (s: Screen) => {
    setError('');
    setCode('');
    setPin('');
    setPin2('');
    setScreen(s);
  };

  const run = async (fn: () => Promise<void>) => {
    setBusy(true);
    setError('');
    try {
      await fn();
    } catch (e) {
      setError(messageOf(e));
      if (e instanceof ApiError && e.retryAfter) {
        // a wait after wrong PINs, or after asking for too many codes
        setPinWait(e.retryAfter);
        setWait(e.retryAfter);
      }
    } finally {
      setBusy(false);
    }
  };

  const openApp = async () => {
    const { data } = await api.getAll();
    hydrateStorage(data);
    setError('');
    setScreen('app');
  };

  const lock = useCallback(async () => {
    if (locking.current) return;
    locking.current = true;
    try {
      await flushStorage();
      await api.lock();
      clearStorage();
      go('unlock');
    } finally {
      locking.current = false;
    }
  }, []);

  // If the server says the PIN key ran out, go back to the PIN screen.
  useEffect(() => {
    setSaveErrorHandler((status) => {
      if (status === 423) { clearStorage(); go('unlock'); }
      if (status === 401) { api.forgetSession(); clearStorage(); go('login'); }
    });
    return () => setSaveErrorHandler(null);
  }, []);

  // First look: is there a signed-in session on this device?
  useEffect(() => {
    if (!hasSession()) return;
    api.me()
      .then((m) => {
        setEmail(m.user.email);
        go(m.needsPin ? 'makepin' : 'unlock');
      })
      .catch((e) => {
        if (e instanceof ApiError && e.status === 401) { api.forgetSession(); go('login'); }
        else { setError(messageOf(e)); setScreen('unlock'); }
      });
  }, []);

  if (screen === 'app') return <>{children({ onLock: lock })}</>;

  if (screen === 'loading') {
    return (
      <div className="flex min-h-screen items-center justify-center bg-neutral-950 text-emerald-400">
        <Loader2 className="h-8 w-8 animate-spin" aria-label="Loading" />
      </div>
    );
  }

  if (screen === 'signup') {
    return (
      <Shell title="Make your account" note="Your money notes stay in your own account. Nobody else can see them.">
        <input className={input} placeholder="Name" value={name} onChange={(e) => setName(e.target.value)} autoComplete="name" />
        <input className={input} placeholder="Gmail" type="email" value={email} onChange={(e) => setEmail(e.target.value)} autoComplete="email" />
        <input className={input} placeholder="Password (8 or more characters)" type="password" value={password} onChange={(e) => setPassword(e.target.value)} autoComplete="new-password" />
        <Message text={error} />
        <button className={primary} disabled={busy} onClick={() => run(async () => {
          const r = await api.signup(name, email, password);
          setCodeKind('signup');
          setWait(r.resendAfter);
          go('code');
        })}>{busy ? 'Please wait' : 'Sign up'}</button>
        <button className={link} onClick={() => go('login')}>I already have an account</button>
      </Shell>
    );
  }

  if (screen === 'login') {
    return (
      <Shell title="Sign in">
        <input className={input} placeholder="Gmail" type="email" value={email} onChange={(e) => setEmail(e.target.value)} autoComplete="email" />
        <input className={input} placeholder="Password" type="password" value={password} onChange={(e) => setPassword(e.target.value)} autoComplete="current-password" />
        <Message text={error} />
        <button className={primary} disabled={busy} onClick={() => run(async () => {
          const r = await api.login(email, password);
          if (r.needsCode) { setCodeKind('device'); setWait(r.resendAfter ?? 60); go('code'); }
          else go(r.needsPin ? 'makepin' : 'unlock');
        })}>{busy ? 'Please wait' : 'Sign in'}</button>
        <div className="flex justify-between">
          <button className={link} onClick={() => go('forgot-password')}>Forgot password</button>
          <button className={link} onClick={() => go('signup')}>Make an account</button>
        </div>
      </Shell>
    );
  }

  if (screen === 'code') {
    return (
      <Shell title="Check your email" note={`We sent a 6-digit code to ${email}. It works for 10 minutes.`}>
        <div className="flex items-center gap-2 text-neutral-500"><Mail className="h-4 w-4" /><span className="text-sm">{email}</span></div>
        <input className={`${input} tracking-[0.5em]`} inputMode="numeric" maxLength={6} placeholder="000000" value={code}
          onChange={(e) => setCode(e.target.value.replace(/\D/g, ''))} autoFocus aria-label="6-digit code" />
        <Message text={error} />
        <button className={primary} disabled={busy || code.length !== 6} onClick={() => run(async () => {
          const r = await api.verify(email, code);
          go(r.needsPin ? 'makepin' : 'unlock');
        })}>{busy ? 'Please wait' : 'Continue'}</button>
        <div className="flex justify-between">
          <button className={link} disabled={wait > 0 || busy} onClick={() => run(async () => {
            const r = await api.resend(email, codeKind);
            setWait(r.resendAfter);
          })}>{wait > 0 ? `Send again in ${wait}s` : 'Send again'}</button>
          <button className={link} onClick={() => go(codeKind === 'signup' ? 'signup' : 'login')}>Change email</button>
        </div>
        <p className="text-xs text-neutral-500">Didn't get the code? Check your email address.</p>
      </Shell>
    );
  }

  if (screen === 'makepin') {
    return (
      <Shell title="Make a PIN" note="You will type it each time you open the app. Use 4 to 6 digits.">
        <input className={`${input} tracking-[0.5em]`} type="password" inputMode="numeric" maxLength={6} placeholder="PIN"
          value={pin} onChange={(e) => setPin(e.target.value.replace(/\D/g, ''))} autoFocus aria-label="New PIN" />
        <input className={`${input} tracking-[0.5em]`} type="password" inputMode="numeric" maxLength={6} placeholder="PIN again"
          value={pin2} onChange={(e) => setPin2(e.target.value.replace(/\D/g, ''))} aria-label="PIN again" />
        <Message text={error} />
        <button className={primary} disabled={busy || pin.length < 4} onClick={() => run(async () => {
          if (pin !== pin2) throw new ApiError(400, "The two PINs don't match");
          await api.setPin(pin);
          await openApp();
        })}>{busy ? 'Please wait' : 'Save PIN'}</button>
      </Shell>
    );
  }

  if (screen === 'unlock') {
    return (
      <Shell title="Enter your PIN">
        <div className="flex items-center gap-2 text-neutral-500"><Lock className="h-4 w-4" /><span className="text-sm">{email || 'Your account'}</span></div>
        <input className={`${input} tracking-[0.5em]`} type="password" inputMode="numeric" maxLength={6} placeholder="PIN"
          value={pin} onChange={(e) => setPin(e.target.value.replace(/\D/g, ''))} autoFocus aria-label="PIN"
          onKeyDown={(e) => { if (e.key === 'Enter') document.getElementById('unlock-btn')?.click(); }} />
        <Message text={error} />
        {pinWait > 0 && <p className="text-sm text-neutral-400">Try again in {pinWait}s</p>}
        <button id="unlock-btn" className={primary} disabled={busy || pin.length < 4 || pinWait > 0} onClick={() => run(async () => {
          try {
            await api.unlock(pin);
          } catch (e) {
            setPin('');
            throw e;
          }
          await openApp();
        })}>{busy ? 'Please wait' : 'Open'}</button>
        <div className="flex justify-between">
          <button className={link} onClick={() => run(async () => {
            const r = await api.forgotPin();
            setWait(r.resendAfter);
            go('forgot-pin');
          })}>Forgot PIN</button>
          <button className={link} onClick={async () => { await api.logout(); clearStorage(); setPassword(''); go('login'); }}>Log out</button>
        </div>
      </Shell>
    );
  }

  if (screen === 'forgot-pin') {
    return (
      <Shell title="Make a new PIN" note={`We sent a code to ${email}.`}>
        <input className={`${input} tracking-[0.5em]`} inputMode="numeric" maxLength={6} placeholder="000000" value={code}
          onChange={(e) => setCode(e.target.value.replace(/\D/g, ''))} autoFocus aria-label="6-digit code" />
        <input className={`${input} tracking-[0.5em]`} type="password" inputMode="numeric" maxLength={6} placeholder="New PIN"
          value={pin} onChange={(e) => setPin(e.target.value.replace(/\D/g, ''))} aria-label="New PIN" />
        <Message text={error} />
        <button className={primary} disabled={busy || code.length !== 6 || pin.length < 4} onClick={() => run(async () => {
          await api.resetPin(code, pin);
          await openApp();
        })}>{busy ? 'Please wait' : 'Save new PIN'}</button>
        <button className={link} onClick={() => go('unlock')}>Back</button>
      </Shell>
    );
  }

  if (screen === 'forgot-password') {
    return (
      <Shell title="Forgot password" note="We will email you a code.">
        <input className={input} placeholder="Gmail" type="email" value={email} onChange={(e) => setEmail(e.target.value)} autoComplete="email" />
        <Message text={error} />
        <button className={primary} disabled={busy} onClick={() => run(async () => {
          const r = await api.forgotPassword(email);
          setWait(r.resendAfter);
          go('reset-password');
        })}>{busy ? 'Please wait' : 'Send code'}</button>
        <button className={link} onClick={() => go('login')}>Back</button>
      </Shell>
    );
  }

  // reset-password
  return (
    <Shell title="New password" note={`If ${email} has an account, a code is on its way.`}>
      <input className={`${input} tracking-[0.5em]`} inputMode="numeric" maxLength={6} placeholder="000000" value={code}
        onChange={(e) => setCode(e.target.value.replace(/\D/g, ''))} autoFocus aria-label="6-digit code" />
      <input className={input} placeholder="New password (8 or more characters)" type="password" value={password}
        onChange={(e) => setPassword(e.target.value)} autoComplete="new-password" />
      <Message text={error} />
      <button className={primary} disabled={busy || code.length !== 6} onClick={() => run(async () => {
        await api.resetPassword(email, code, password);
        setPassword('');
        go('login');
      })}>{busy ? 'Please wait' : 'Save password'}</button>
      <button className={link} onClick={() => go('login')}>Back</button>
    </Shell>
  );
};
