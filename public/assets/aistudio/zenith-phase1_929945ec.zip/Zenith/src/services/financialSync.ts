import { PersonDebtRecord, CalendarEvent } from '../types';

/**
 * Ensures all debt records with expected repayment dates and milestones have corresponding Calendar alarm events.
 */
export function syncDebtsToCalendarEvents(
  debtRecords: PersonDebtRecord[],
  currentEvents: CalendarEvent[]
): CalendarEvent[] {
  let updatedEvents = [...currentEvents];

  debtRecords.forEach((debt) => {
    // 1. Sync milestone alerts
    if (debt.milestones && debt.milestones.length > 0) {
      debt.milestones.forEach((m) => {
        const mEventId = `evt-milestone-${m.id}`;
        const existingMIdx = updatedEvents.findIndex((e) => e.id === mEventId);
        const mTitle = `🔔 ${m.label}`;
        const mDesc = `Scheduled milestone alert for ${debt.personName}. Milestone date: ${m.date}. Alarm active.`;

        if (existingMIdx >= 0) {
          updatedEvents[existingMIdx] = {
            ...updatedEvents[existingMIdx],
            title: mTitle,
            description: mDesc,
            date: m.date,
            isCompleted: m.status === 'cleared',
            isAlarmEnabled: m.isAlarmEnabled,
            receivablePerson: debt.personName,
            amount: m.amount ?? debt.amount,
          };
        } else {
          updatedEvents.push({
            id: mEventId,
            title: mTitle,
            description: mDesc,
            date: m.date,
            time: '09:00',
            type: 'salary',
            color: '#8b5cf6',
            amount: m.amount ?? debt.amount,
            isCompleted: m.status === 'cleared',
            isAlarmEnabled: m.isAlarmEnabled,
            receivablePerson: debt.personName,
          });
        }
      });
    }

    // 2. Primary return date
    if (debt.type === 'given_udhaar' && debt.expectedReturnDate) {
      const eventId = `evt-debt-${debt.id}`;
      const existingIdx = updatedEvents.findIndex(
        (e) => e.id === eventId || (e.receivablePerson === debt.personName && e.date === debt.expectedReturnDate)
      );

      const title = `🔔 Collect ${debt.amount.toLocaleString('en-PK')} from ${debt.personName}`;
      const description = `Scheduled repayment collection for a loan of ${debt.amount.toLocaleString('en-PK')}. Status: ${debt.status === 'cleared' ? 'Settled' : 'Pending Recovery'}.`;

      if (existingIdx >= 0) {
        updatedEvents[existingIdx] = {
          ...updatedEvents[existingIdx],
          title,
          description,
          date: debt.expectedReturnDate,
          amount: debt.amount,
          isCompleted: debt.status === 'cleared',
          isAlarmEnabled: true,
          receivablePerson: debt.personName,
        };
      } else {
        updatedEvents.push({
          id: eventId,
          title,
          description,
          date: debt.expectedReturnDate,
          time: '09:00',
          type: 'salary',
          color: '#10b981',
          amount: debt.amount,
          isCompleted: debt.status === 'cleared',
          isAlarmEnabled: true,
          receivablePerson: debt.personName,
        });
      }
    }
  });

  return updatedEvents;
}
