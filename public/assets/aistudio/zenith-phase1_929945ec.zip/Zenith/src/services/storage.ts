import {
  CategoryAllocation,
  SalaryConfig,
  SecuritySettings,
} from '../types';

import { api } from './api';

const STORAGE_KEYS = {
  NOTES: 'zenith_notes_v3',
  CALENDAR: 'zenith_calendar_v3',
  SALARY: 'zenith_salary_v3',
  BUDGET: 'zenith_budget_v3',
  CATEGORIES: 'zenith_categories_v1',
  SECURITY: 'zenith_security_v1',
  NOTIFICATIONS: 'zenith_notifications_v3',
  SYNC_DEVICES: 'zenith_sync_devices_v1',
  THEME: 'zenith_theme_v1',
  ACCENT: 'zenith_accent_v1',
  SAVINGS_GOALS: 'zenith_savings_goals_v1',
  CURRENCY: 'zenith_currency_v1',
  CURRENCY_RATES: 'zenith_currency_rates_v1',
  DEBT_RECORDS: 'zenith_debt_records_v3',
  EXPENSE_ITEMS: 'zenith_month_expenses_v3',
  MONTHLY_ACCOUNTS: 'zenith_monthly_accounts_v3',
};

// A new account starts empty. These are only neutral starting settings, with no money in them.
export const INITIAL_SALARY_CONFIG: SalaryConfig = {
  baseSalary: 0,
  payPeriod: 'monthly',
  hoursPerWeek: 40,
  payDayFrequency: 'monthly',
  payDayDate: 1,
  federalTaxRate: 0,
  stateTaxRate: 0,
  ficaTaxRate: 0,
  retirement401kPct: 0,
  healthInsuranceMonthly: 0,
  otherDeductionsMonthly: 0,
  bonusMonthlyAvg: 0,
  overtimeHoursPerMonth: 0,
  overtimeMultiplier: 1.5,
  currency: '₨',
  history: [],
};

export const INITIAL_CATEGORIES: CategoryAllocation[] = [
  { category: 'Housing', monthlyLimit: 1850, bucket: 'need', color: '#6366f1' },
  { category: 'Utilities', monthlyLimit: 220, bucket: 'need', color: '#0ea5e9' },
  { category: 'Groceries', monthlyLimit: 550, bucket: 'need', color: '#10b981' },
  { category: 'Transportation', monthlyLimit: 300, bucket: 'need', color: '#14b8a6' },
  { category: 'Healthcare', monthlyLimit: 150, bucket: 'need', color: '#f43f5e' },
  { category: 'Dining & Food', monthlyLimit: 350, bucket: 'want', color: '#f59e0b' },
  { category: 'Entertainment', monthlyLimit: 200, bucket: 'want', color: '#a855f7' },
  { category: 'Subscriptions', monthlyLimit: 100, bucket: 'want', color: '#ec4899' },
  { category: 'Shopping', monthlyLimit: 250, bucket: 'want', color: '#f97316' },
  { category: 'Personal Care', monthlyLimit: 120, bucket: 'want', color: '#84cc16' },
  { category: 'Debt & Loans', monthlyLimit: 0, bucket: 'need', color: '#ef4444' },
  { category: 'Savings & Investments', monthlyLimit: 1300, bucket: 'savings', color: '#059669' },
  { category: 'Other', monthlyLimit: 150, bucket: 'want', color: '#64748b' },
];

export const INITIAL_SECURITY: SecuritySettings = {
  isLocked: false,
  isConfigured: true,
  pinHash: '',
  biometricsEnabled: false,
  e2eeEnabled: false,
  masterSalt: '',
  autoLockMinutes: 5,
  lastActive: Date.now(),
};

// ---------------------------------------------------------------------------
// Each person's data lives on the server, under their own account.
// While the app is open it is kept in this memory copy, and every change is
// sent to the server a moment later. Nothing is kept in the browser's storage.
// ---------------------------------------------------------------------------
const memory = new Map<string, string>();
const timers = new Map<string, number>();
const latest = new Map<string, unknown>();
let onSaveError: ((status: number) => void) | null = null;

export function hydrateStorage(data: Record<string, string>): void {
  memory.clear();
  for (const [k, v] of Object.entries(data)) memory.set(k, v);
}

export function clearStorage(): void {
  for (const t of timers.values()) window.clearTimeout(t);
  timers.clear();
  latest.clear();
  memory.clear();
}

export function setSaveErrorHandler(fn: ((status: number) => void) | null): void {
  onSaveError = fn;
}

async function pushKey(key: string): Promise<void> {
  if (!latest.has(key)) return;
  const value = latest.get(key);
  latest.delete(key);
  timers.delete(key);
  try {
    await api.putKey(key, value);
  } catch (err: any) {
    console.error('Could not save', key, err);
    if (onSaveError && typeof err?.status === 'number') onSaveError(err.status);
  }
}

// Send everything waiting to the server now (used before locking).
export async function flushStorage(): Promise<void> {
  const keys = Array.from(latest.keys());
  for (const k of keys) {
    const t = timers.get(k);
    if (t) window.clearTimeout(t);
  }
  await Promise.all(keys.map(pushKey));
}

export function loadFromStorage<T>(key: string, defaultValue: T): T {
  try {
    const raw = memory.get(key);
    if (raw === undefined) return defaultValue;
    return JSON.parse(raw) as T;
  } catch {
    return defaultValue;
  }
}

export function saveToStorage<T>(key: string, value: T): void {
  const raw = JSON.stringify(value);
  if (memory.get(key) === raw) return; // nothing changed
  memory.set(key, raw);
  latest.set(key, value);
  const old = timers.get(key);
  if (old) window.clearTimeout(old);
  timers.set(key, window.setTimeout(() => { void pushKey(key); }, 600));
}

export { STORAGE_KEYS };
