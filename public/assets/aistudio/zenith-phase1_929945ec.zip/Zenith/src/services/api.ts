// Talks to the Zenith server. The session key lives on this device.
// The PIN unlock key lives only in memory, so closing or reloading the page asks for the PIN again.

const LS_SESSION = 'zenith_session_token';
const LS_DEVICE = 'zenith_device_id';

let unlockToken: string | null = null;

export class ApiError extends Error {
  status: number;
  retryAfter?: number;
  triesLeft?: number;
  constructor(status: number, message: string, extra: { retryAfter?: number; triesLeft?: number } = {}) {
    super(message);
    this.status = status;
    this.retryAfter = extra.retryAfter;
    this.triesLeft = extra.triesLeft;
  }
}

export interface PublicUser { id: string; name: string; email: string }

export function getDeviceId(): string {
  let id = localStorage.getItem(LS_DEVICE);
  if (!id || !/^[a-f0-9]{32,64}$/.test(id)) {
    const bytes = new Uint8Array(16);
    crypto.getRandomValues(bytes);
    id = Array.from(bytes, (b) => b.toString(16).padStart(2, '0')).join('');
    localStorage.setItem(LS_DEVICE, id);
  }
  return id;
}

export const hasSession = () => Boolean(localStorage.getItem(LS_SESSION));
const setSession = (t: string | null) => (t ? localStorage.setItem(LS_SESSION, t) : localStorage.removeItem(LS_SESSION));
export const setUnlock = (t: string | null) => { unlockToken = t; };

async function call<T = any>(method: string, path: string, body?: unknown, opts: { session?: boolean; unlock?: boolean } = {}): Promise<T> {
  const headers: Record<string, string> = { 'content-type': 'application/json' };
  const session = localStorage.getItem(LS_SESSION);
  if (opts.session !== false && session) headers.authorization = `Bearer ${session}`;
  if (opts.unlock && unlockToken) headers['x-unlock-token'] = unlockToken;
  let res: Response;
  try {
    res = await fetch(`/api${path}`, { method, headers, body: body === undefined ? undefined : JSON.stringify(body) });
  } catch {
    throw new ApiError(0, "Can't reach the server. Check your internet");
  }
  let json: any = {};
  try { json = await res.json(); } catch { /* empty body */ }
  if (!res.ok) throw new ApiError(res.status, json.error || 'Something went wrong', { retryAfter: json.retryAfter, triesLeft: json.triesLeft });
  return json as T;
}

export const api = {
  signup: (name: string, email: string, password: string) =>
    call<{ email: string; resendAfter: number }>('POST', '/auth/signup', { name, email, password }, { session: false }),

  verify: async (email: string, code: string) => {
    const r = await call<{ token: string; user: PublicUser; needsPin: boolean }>(
      'POST', '/auth/verify', { email, code, deviceId: getDeviceId() }, { session: false });
    setSession(r.token);
    return r;
  },

  resend: (email: string, kind: 'signup' | 'device') =>
    call<{ resendAfter: number }>('POST', '/auth/resend', { email, kind }, { session: false }),

  login: async (email: string, password: string) => {
    const r = await call<{ token?: string; user?: PublicUser; needsPin?: boolean; needsCode?: boolean; resendAfter?: number }>(
      'POST', '/auth/login', { email, password, deviceId: getDeviceId() }, { session: false });
    if (r.token) setSession(r.token);
    return r;
  },

  forgotPassword: (email: string) => call<{ resendAfter: number }>('POST', '/auth/forgot-password', { email }, { session: false }),
  resetPassword: (email: string, code: string, password: string) =>
    call('POST', '/auth/reset-password', { email, code, password }, { session: false }),

  me: () => call<{ user: PublicUser; needsPin: boolean; unlocked: boolean }>('GET', '/me', undefined, { unlock: true }),

  setPin: async (pin: string) => {
    const r = await call<{ unlockToken: string }>('POST', '/device/pin', { pin });
    setUnlock(r.unlockToken);
  },
  unlock: async (pin: string) => {
    const r = await call<{ unlockToken: string }>('POST', '/device/unlock', { pin });
    setUnlock(r.unlockToken);
  },
  lock: async () => {
    try { await call('POST', '/device/lock'); } catch { /* already locked or offline */ }
    setUnlock(null);
  },
  forgotPin: () => call<{ resendAfter: number }>('POST', '/device/forgot-pin'),
  resetPin: async (code: string, pin: string) => {
    const r = await call<{ unlockToken: string }>('POST', '/device/reset-pin', { code, pin });
    setUnlock(r.unlockToken);
  },

  logout: async () => {
    try { await call('POST', '/auth/logout'); } catch { /* still clear this device */ }
    setSession(null);
    setUnlock(null);
  },
  forgetSession: () => { setSession(null); setUnlock(null); },

  getAll: () => call<{ data: Record<string, string> }>('GET', '/data', undefined, { unlock: true }),
  putKey: (key: string, value: unknown) => call('PUT', `/data/${key}`, { value }, { unlock: true }),

  deleteCode: () => call<{ resendAfter: number }>('POST', '/account/delete-code', undefined, { unlock: true }),
  deleteAccount: async (code: string) => {
    await call('DELETE', '/account', { code }, { unlock: true });
    setSession(null);
    setUnlock(null);
  },
};
