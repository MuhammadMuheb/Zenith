# Zenith: Phase 1 (accounts and server)

## Run it on your computer
1. Install Node 22.13 or newer.
2. `npm install`
3. `npm run dev`, then open http://localhost:3000
4. Sign up. With no email settings, the 6-digit code is printed in the terminal
   and shown at `http://localhost:3000/api/dev/mailbox?email=you@gmail.com`.

## Check the backend
Start the server for tests, then run the checks (39 yes/no tests):

    SKIP_VITE=1 NODE_ENV=test PORT=3101 DATABASE_PATH=/tmp/z.db npx tsx server/index.ts
    BASE=http://localhost:3101 npm run check:phase1

## What is in Phase 1
- `server/`: sign-up, emailed code, login, PIN per device, wrong-PIN waiting time,
  forgot PIN, forgot password, log out, delete account, and each person's own data.
- `src/components/AuthGate.tsx`: sign-up, code, PIN and unlock screens.
- `src/services/api.ts` and `storage.ts`: data is kept per account on the server.
- Removed: the 1234 back door and LockScreen, all of the owner's sample data,
  the Father loan banner, the auto-made "Master Financial" note, and the fixed `Rs. 96k` badge.
- `MoneyAccountView.tsx` is a temporary plain Home with no personal figures. Phase 4 replaces it.

## Before you put it on the internet
- Set the SMTP lines in `.env` so real emails are sent (a service with a free plan is fine).
- Set `SERVER_SECRET` to long random text, and `TRUST_PROXY=1` if your host uses a proxy.
- Use HTTPS only.
- The old owner data still exists in the git history of this repo. If the repo will be public,
  start a fresh repository (or rewrite the history) before publishing.

## Not in Phase 1 (later phases)
- Fingerprint and face (Phase 9). The old Security window still opens but its PIN settings do nothing.
- The month engine, Still to save, and the new pages (Phases 2 to 7).
