import crypto from 'node:crypto';
import { SERVER_SECRET } from './db.ts';

export function randomToken(bytes = 32): string {
  return crypto.randomBytes(bytes).toString('hex');
}

export function sha256hex(value: string): string {
  return crypto.createHash('sha256').update(value).digest('hex');
}

export function hmac(value: string): string {
  return crypto.createHmac('sha256', SERVER_SECRET).update(value).digest('hex');
}

export function safeEqual(a: string, b: string): boolean {
  const x = Buffer.from(a);
  const y = Buffer.from(b);
  return x.length === y.length && crypto.timingSafeEqual(x, y);
}

export function randomCode(): string {
  return String(crypto.randomInt(0, 1_000_000)).padStart(6, '0');
}

// Passwords: scrambled with scrypt and a random salt per person.
export function hashPassword(password: string): string {
  const salt = crypto.randomBytes(16).toString('hex');
  const hash = crypto.scryptSync(password, salt, 64).toString('hex');
  return `scrypt$${salt}$${hash}`;
}

export function verifyPassword(password: string, stored: string): boolean {
  const [scheme, salt, hash] = stored.split('$');
  if (scheme !== 'scrypt' || !salt || !hash) return false;
  const test = crypto.scryptSync(password, salt, 64).toString('hex');
  return safeEqual(test, hash);
}

// PINs: scrypt with a per-device salt plus the server secret.
export function hashPin(pin: string, salt: string): string {
  return crypto.scryptSync(pin, salt + SERVER_SECRET, 32).toString('hex');
}

const EASY_PINS = new Set(['1234', '4321', '0000', '1111', '2222', '3333', '4444', '5555', '6666', '7777', '8888', '9999', '1212', '2580', '123456', '654321', '000000', '111111', '121212', '112233']);

export function pinProblem(pin: string): string | null {
  if (!/^\d{4,6}$/.test(pin)) return 'Use 4 to 6 digits';
  if (EASY_PINS.has(pin)) return 'That PIN is too easy. Pick another';
  if (/^(\d)\1+$/.test(pin)) return 'That PIN is too easy. Pick another';
  const d = pin.split('').map(Number);
  const up = d.every((n, i) => i === 0 || n === d[i - 1] + 1);
  const down = d.every((n, i) => i === 0 || n === d[i - 1] - 1);
  if (up || down) return 'That PIN is too easy. Pick another';
  return null;
}

// Fixed-window limiter. Returns seconds to wait, or 0 when allowed.
const hits = new Map<string, { n: number; reset: number }>();
export function rateLimit(key: string, max: number, windowMs: number): number {
  const now = Date.now();
  const cur = hits.get(key);
  if (!cur || cur.reset <= now) {
    hits.set(key, { n: 1, reset: now + windowMs });
    return 0;
  }
  cur.n += 1;
  if (cur.n > max) return Math.ceil((cur.reset - now) / 1000);
  return 0;
}
setInterval(() => {
  const now = Date.now();
  for (const [k, v] of hits) if (v.reset <= now) hits.delete(k);
}, 60_000).unref();
