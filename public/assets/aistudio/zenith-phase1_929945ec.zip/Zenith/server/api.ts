import express, { Router } from 'express';
import type { NextFunction, Request, Response } from 'express';
import crypto from 'node:crypto';
import { q } from './db.ts';
import { devMailbox, mailIsDev, sendMail } from './mailer.ts';
import {
  hashPassword, hashPin, hmac, pinProblem, randomCode, randomToken,
  rateLimit, safeEqual, sha256hex, verifyPassword,
} from './security.ts';

export const api = Router();

const DAY = 24 * 60 * 60 * 1000;
const SESSION_TTL = 30 * DAY;
const UNLOCK_TTL = 12 * 60 * 60 * 1000;
const CODE_TTL = 10 * 60 * 1000;
const RESEND_AFTER = 60;

type CodeKind = 'signup' | 'device' | 'pin' | 'password' | 'delete';
interface User { id: string; name: string; email: string; pass_hash: string; verified: number }
interface Device { id: string; user_id: string; pin_hash: string | null; pin_salt: string | null; pin_fails: number; locked_until: number }
interface Session { token_hash: string; user_id: string; device_id: string; unlock_hash: string | null; unlock_expires: number; expires_at: number }

const fail = (res: Response, status: number, error: string, extra: object = {}) =>
  res.status(status).json({ error, ...extra });

const ipOf = (req: Request) => req.ip || 'unknown';
const emailOk = (e: unknown): e is string =>
  typeof e === 'string' && e.length <= 254 && /^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/.test(e);
const cleanEmail = (e: string) => e.trim().toLowerCase();
const deviceOk = (d: unknown): d is string => typeof d === 'string' && /^[a-f0-9]{32,64}$/.test(d);

api.use((_req, res, next) => {
  res.setHeader('Cache-Control', 'no-store');
  next();
});
api.use(express.json({ limit: '2mb' }));

// Same limit for every API call from one address.
api.use((req, res, next) => {
  const wait = rateLimit(`all:${ipOf(req)}`, 600, 60_000);
  if (wait) return fail(res, 429, 'Too many requests. Wait a moment', { retryAfter: wait });
  next();
});

// ---------- helpers ----------

function userPublic(u: User) {
  return { id: u.id, name: u.name, email: u.email };
}

async function issueCode(user: User, kind: CodeKind): Promise<{ wait?: number }> {
  const now = Date.now();
  const last = q.get<{ created_at: number; used: number }>(
    'SELECT created_at, used FROM codes WHERE user_id = ? AND kind = ? ORDER BY id DESC LIMIT 1', user.id, kind);
  if (last && !last.used && now - last.created_at < RESEND_AFTER * 1000) {
    return { wait: Math.ceil((RESEND_AFTER * 1000 - (now - last.created_at)) / 1000) };
  }
  const hour = q.get<{ c: number }>('SELECT COUNT(*) AS c FROM codes WHERE user_id = ? AND created_at > ?', user.id, now - 3_600_000);
  if (hour && hour.c >= 6) return { wait: 900 };

  const code = randomCode();
  q.run('UPDATE codes SET used = 1 WHERE user_id = ? AND kind = ? AND used = 0', user.id, kind);
  q.run(
    'INSERT INTO codes (user_id, kind, code_hash, expires_at, tries_left, used, created_at) VALUES (?, ?, ?, ?, 5, 0, ?)',
    user.id, kind, hmac(`${user.id}:${kind}:${code}`), now + CODE_TTL, now);

  const why: Record<CodeKind, string> = {
    signup: 'finish making your Zenith account',
    device: 'sign in on a new device',
    pin: 'set a new PIN',
    password: 'set a new password',
    delete: 'delete your Zenith account',
  };
  try {
    await sendMail(user.email, `Your Zenith code: ${code}`,
      `Hi ${user.name},\n\nUse this code to ${why[kind]}:\n\n${code}\n\nIt works for 10 minutes. If you didn't ask for it, ignore this email.\n`);
  } catch (err) {
    q.run('UPDATE codes SET used = 1 WHERE user_id = ? AND kind = ? AND used = 0', user.id, kind);
    throw err;
  }
  return {};
}

type CodeResult = { ok: true } | { ok: false; status: number; error: string; extra?: object };

function checkCode(user: User, kind: CodeKind, code: unknown): CodeResult {
  if (typeof code !== 'string' || !/^\d{6}$/.test(code.trim())) {
    return { ok: false, status: 400, error: 'That code is wrong' };
  }
  const now = Date.now();
  const row = q.get<{ id: number; code_hash: string; expires_at: number; tries_left: number }>(
    'SELECT id, code_hash, expires_at, tries_left FROM codes WHERE user_id = ? AND kind = ? AND used = 0 ORDER BY id DESC LIMIT 1',
    user.id, kind);
  if (!row || row.expires_at < now) {
    return { ok: false, status: 400, error: 'That code has run out. Ask for a new one' };
  }
  if (row.tries_left <= 0) {
    return { ok: false, status: 429, error: 'Too many wrong tries. Ask for a new code' };
  }
  if (!safeEqual(hmac(`${user.id}:${kind}:${code.trim()}`), row.code_hash)) {
    q.run('UPDATE codes SET tries_left = tries_left - 1 WHERE id = ?', row.id);
    return { ok: false, status: 400, error: 'That code is wrong', extra: { triesLeft: row.tries_left - 1 } };
  }
  q.run('UPDATE codes SET used = 1 WHERE id = ?', row.id);
  return { ok: true };
}

function registerDevice(userId: string, deviceId: string): Device {
  const now = Date.now();
  const existing = q.get<Device>('SELECT * FROM devices WHERE id = ? AND user_id = ?', deviceId, userId);
  if (existing) {
    q.run('UPDATE devices SET last_used = ? WHERE id = ? AND user_id = ?', now, deviceId, userId);
    return existing;
  }
  q.run('INSERT INTO devices (id, user_id, last_used) VALUES (?, ?, ?)', deviceId, userId, now);
  return q.get<Device>('SELECT * FROM devices WHERE id = ? AND user_id = ?', deviceId, userId)!;
}

function newSession(userId: string, deviceId: string): string {
  const token = randomToken();
  const now = Date.now();
  q.run(
    'INSERT INTO sessions (token_hash, user_id, device_id, expires_at, created_at) VALUES (?, ?, ?, ?, ?)',
    sha256hex(token), userId, deviceId, now + SESSION_TTL, now);
  return token;
}

function grantUnlock(tokenHash: string): string {
  const unlock = randomToken();
  q.run('UPDATE sessions SET unlock_hash = ?, unlock_expires = ? WHERE token_hash = ?',
    sha256hex(unlock), Date.now() + UNLOCK_TTL, tokenHash);
  return unlock;
}

function getUser(id: string): User | undefined {
  return q.get<User>('SELECT * FROM users WHERE id = ?', id);
}

// ---------- guards ----------

function requireSession(req: Request, res: Response, next: NextFunction) {
  const auth = req.headers.authorization || '';
  const token = auth.startsWith('Bearer ') ? auth.slice(7) : '';
  if (!token) return fail(res, 401, 'Sign in first');
  const s = q.get<Session>('SELECT * FROM sessions WHERE token_hash = ? AND expires_at > ?', sha256hex(token), Date.now());
  if (!s || !q.get('SELECT 1 FROM devices WHERE id = ? AND user_id = ?', s.device_id, s.user_id)) {
    return fail(res, 401, 'Sign in first');
  }
  res.locals.session = s;
  next();
}

function requireUnlock(req: Request, res: Response, next: NextFunction) {
  requireSession(req, res, () => {
    const s = res.locals.session as Session;
    const unlock = String(req.headers['x-unlock-token'] || '');
    if (!unlock || !s.unlock_hash || s.unlock_expires < Date.now() || !safeEqual(sha256hex(unlock), s.unlock_hash)) {
      return fail(res, 423, 'Enter your PIN');
    }
    next();
  });
}

// ---------- sign up and sign in ----------

api.post('/auth/signup', async (req, res) => {
  const { name, email, password } = req.body || {};
  const wait = rateLimit(`signup:${ipOf(req)}`, 10, 3_600_000);
  if (wait) return fail(res, 429, 'Too many tries. Wait a while', { retryAfter: wait });
  if (typeof name !== 'string' || !name.trim() || name.trim().length > 60) return fail(res, 400, 'Enter your name');
  if (!emailOk(email)) return fail(res, 400, "That email doesn't look right");
  if (typeof password !== 'string' || password.length < 8 || password.length > 128) {
    return fail(res, 400, 'Use a password with at least 8 characters');
  }
  const mail = cleanEmail(email);
  let user = q.get<User>('SELECT * FROM users WHERE email = ?', mail);
  if (user && user.verified) return fail(res, 409, 'This email already has an account. Sign in instead');
  if (user) {
    q.run('UPDATE users SET name = ?, pass_hash = ? WHERE id = ?', name.trim(), hashPassword(password), user.id);
  } else {
    const id = crypto.randomUUID();
    q.run('INSERT INTO users (id, name, email, pass_hash, verified, created_at) VALUES (?, ?, ?, ?, 0, ?)',
      id, name.trim(), mail, hashPassword(password), Date.now());
  }
  user = q.get<User>('SELECT * FROM users WHERE email = ?', mail)!;
  try {
    const r = await issueCode(user, 'signup');
    if (r.wait) return fail(res, 429, `Wait ${r.wait} seconds before asking for another code`, { retryAfter: r.wait });
  } catch {
    return fail(res, 502, "Couldn't send the code. Check your email address and try again");
  }
  res.json({ ok: true, email: mail, resendAfter: RESEND_AFTER });
});

api.post('/auth/verify', (req, res) => {
  const { email, code, deviceId } = req.body || {};
  if (!emailOk(email) || !deviceOk(deviceId)) return fail(res, 400, 'That code is wrong');
  const wait = rateLimit(`verify:${ipOf(req)}:${cleanEmail(email)}`, 20, 15 * 60_000);
  if (wait) return fail(res, 429, 'Too many tries. Wait a while', { retryAfter: wait });
  const user = q.get<User>('SELECT * FROM users WHERE email = ?', cleanEmail(email));
  if (!user) return fail(res, 400, 'That code is wrong');
  const kind: CodeKind = user.verified ? 'device' : 'signup';
  const r = checkCode(user, kind, code);
  if (!r.ok) return fail(res, r.status, r.error, r.extra);
  if (!user.verified) q.run('UPDATE users SET verified = 1 WHERE id = ?', user.id);
  const device = registerDevice(user.id, deviceId);
  const token = newSession(user.id, deviceId);
  res.json({ token, user: userPublic(user), needsPin: !device.pin_hash });
});

api.post('/auth/resend', async (req, res) => {
  const { email, kind } = req.body || {};
  if (!emailOk(email) || (kind !== 'signup' && kind !== 'device')) return fail(res, 400, "That email doesn't look right");
  const user = q.get<User>('SELECT * FROM users WHERE email = ?', cleanEmail(email));
  const rightKind = user && (user.verified ? 'device' : 'signup') === kind;
  if (user && rightKind) {
    try {
      const r = await issueCode(user, kind);
      if (r.wait) return fail(res, 429, `Wait ${r.wait} seconds before asking for another code`, { retryAfter: r.wait });
    } catch {
      return fail(res, 502, "Couldn't send the code. Check your email address and try again");
    }
  }
  res.json({ ok: true, resendAfter: RESEND_AFTER });
});

api.post('/auth/login', async (req, res) => {
  const { email, password, deviceId } = req.body || {};
  if (!emailOk(email) || typeof password !== 'string' || !deviceOk(deviceId)) {
    return fail(res, 400, 'Email or password is wrong');
  }
  const mail = cleanEmail(email);
  const wait = rateLimit(`login:${ipOf(req)}:${mail}`, 10, 15 * 60_000);
  if (wait) return fail(res, 429, 'Too many tries. Wait a while', { retryAfter: wait });
  const user = q.get<User>('SELECT * FROM users WHERE email = ?', mail);
  if (!user || !user.verified || !verifyPassword(password, user.pass_hash)) {
    return fail(res, 401, 'Email or password is wrong');
  }
  const device = q.get<Device>('SELECT * FROM devices WHERE id = ? AND user_id = ?', deviceId, user.id);
  if (device) {
    registerDevice(user.id, deviceId);
    const token = newSession(user.id, deviceId);
    return res.json({ token, user: userPublic(user), needsPin: !device.pin_hash });
  }
  try {
    const r = await issueCode(user, 'device');
    if (r.wait) return res.json({ needsCode: true, email: mail, resendAfter: r.wait });
  } catch {
    return fail(res, 502, "Couldn't send the code. Try again in a moment");
  }
  res.json({ needsCode: true, email: mail, resendAfter: RESEND_AFTER });
});

api.post('/auth/forgot-password', async (req, res) => {
  const { email } = req.body || {};
  if (!emailOk(email)) return fail(res, 400, "That email doesn't look right");
  const wait = rateLimit(`forgot:${ipOf(req)}`, 10, 3_600_000);
  if (wait) return fail(res, 429, 'Too many tries. Wait a while', { retryAfter: wait });
  const user = q.get<User>('SELECT * FROM users WHERE email = ?', cleanEmail(email));
  if (user && user.verified) {
    try { await issueCode(user, 'password'); } catch { /* same answer either way */ }
  }
  res.json({ ok: true, resendAfter: RESEND_AFTER });
});

api.post('/auth/reset-password', (req, res) => {
  const { email, code, password } = req.body || {};
  if (!emailOk(email)) return fail(res, 400, "That email doesn't look right");
  if (typeof password !== 'string' || password.length < 8 || password.length > 128) {
    return fail(res, 400, 'Use a password with at least 8 characters');
  }
  const wait = rateLimit(`reset:${ipOf(req)}:${cleanEmail(email)}`, 20, 15 * 60_000);
  if (wait) return fail(res, 429, 'Too many tries. Wait a while', { retryAfter: wait });
  const user = q.get<User>('SELECT * FROM users WHERE email = ?', cleanEmail(email));
  if (!user || !user.verified) return fail(res, 400, 'That code is wrong');
  const r = checkCode(user, 'password', code);
  if (!r.ok) return fail(res, r.status, r.error, r.extra);
  q.run('UPDATE users SET pass_hash = ? WHERE id = ?', hashPassword(password), user.id);
  q.run('DELETE FROM sessions WHERE user_id = ?', user.id);
  res.json({ ok: true });
});

api.get('/me', requireSession, (req, res) => {
  const s = res.locals.session as Session;
  const user = getUser(s.user_id)!;
  const device = q.get<Device>('SELECT * FROM devices WHERE id = ? AND user_id = ?', s.device_id, s.user_id)!;
  const unlock = String(req.headers['x-unlock-token'] || '');
  const unlocked = Boolean(unlock && s.unlock_hash && s.unlock_expires > Date.now() && safeEqual(sha256hex(unlock), s.unlock_hash));
  res.json({ user: userPublic(user), needsPin: !device.pin_hash, unlocked });
});

api.post('/auth/logout', requireSession, (_req, res) => {
  const s = res.locals.session as Session;
  q.run('DELETE FROM sessions WHERE token_hash = ?', s.token_hash);
  q.run('DELETE FROM devices WHERE id = ? AND user_id = ?', s.device_id, s.user_id);
  res.json({ ok: true });
});

// ---------- PIN ----------

api.post('/device/pin', requireSession, (req, res) => {
  const s = res.locals.session as Session;
  const device = q.get<Device>('SELECT * FROM devices WHERE id = ? AND user_id = ?', s.device_id, s.user_id)!;
  if (device.pin_hash) return fail(res, 409, 'This device already has a PIN');
  const pin = String(req.body?.pin ?? '');
  const bad = pinProblem(pin);
  if (bad) return fail(res, 400, bad);
  const salt = randomToken(16);
  q.run('UPDATE devices SET pin_hash = ?, pin_salt = ?, pin_fails = 0, locked_until = 0 WHERE id = ? AND user_id = ?',
    hashPin(pin, salt), salt, s.device_id, s.user_id);
  res.json({ unlockToken: grantUnlock(s.token_hash) });
});

api.post('/device/unlock', requireSession, (req, res) => {
  const s = res.locals.session as Session;
  const device = q.get<Device>('SELECT * FROM devices WHERE id = ? AND user_id = ?', s.device_id, s.user_id)!;
  if (!device.pin_hash || !device.pin_salt) return fail(res, 409, 'Make a PIN first');
  const now = Date.now();
  if (device.locked_until > now) {
    const wait = Math.ceil((device.locked_until - now) / 1000);
    return fail(res, 429, `Too many wrong PINs. Try again in ${wait} seconds`, { retryAfter: wait });
  }
  const pin = String(req.body?.pin ?? '');
  if (!/^\d{4,6}$/.test(pin) || !safeEqual(hashPin(pin, device.pin_salt), device.pin_hash)) {
    const fails = device.pin_fails + 1;
    let lockedUntil = 0;
    let wait = 0;
    if (fails >= 5) {
      wait = Math.min(900, 30 * 2 ** (fails - 5));
      lockedUntil = now + wait * 1000;
    }
    q.run('UPDATE devices SET pin_fails = ?, locked_until = ? WHERE id = ? AND user_id = ?', fails, lockedUntil, s.device_id, s.user_id);
    return fail(res, 401, 'That PIN is wrong', { triesBeforeWait: Math.max(0, 5 - fails), retryAfter: wait });
  }
  q.run('UPDATE devices SET pin_fails = 0, locked_until = 0, last_used = ? WHERE id = ? AND user_id = ?', now, s.device_id, s.user_id);
  res.json({ unlockToken: grantUnlock(s.token_hash) });
});

api.post('/device/lock', requireSession, (_req, res) => {
  const s = res.locals.session as Session;
  q.run('UPDATE sessions SET unlock_hash = NULL, unlock_expires = 0 WHERE token_hash = ?', s.token_hash);
  res.json({ ok: true });
});

api.post('/device/forgot-pin', requireSession, async (_req, res) => {
  const s = res.locals.session as Session;
  try {
    const r = await issueCode(getUser(s.user_id)!, 'pin');
    if (r.wait) return fail(res, 429, `Wait ${r.wait} seconds before asking for another code`, { retryAfter: r.wait });
  } catch {
    return fail(res, 502, "Couldn't send the code. Try again in a moment");
  }
  res.json({ ok: true, resendAfter: RESEND_AFTER });
});

api.post('/device/reset-pin', requireSession, (req, res) => {
  const s = res.locals.session as Session;
  const user = getUser(s.user_id)!;
  const bad = pinProblem(String(req.body?.pin ?? ''));
  if (bad) return fail(res, 400, bad);
  const r = checkCode(user, 'pin', req.body?.code);
  if (!r.ok) return fail(res, r.status, r.error, r.extra);
  const salt = randomToken(16);
  q.run('UPDATE devices SET pin_hash = ?, pin_salt = ?, pin_fails = 0, locked_until = 0 WHERE id = ? AND user_id = ?',
    hashPin(String(req.body.pin), salt), salt, s.device_id, s.user_id);
  res.json({ unlockToken: grantUnlock(s.token_hash) });
});

// ---------- each person's own data ----------

const KEY_RE = /^zenith_[a-z0-9_]{1,60}$/;
const MAX_VALUE = 1_500_000;

api.get('/data', requireUnlock, (_req, res) => {
  const s = res.locals.session as Session;
  const rows = q.all<{ key: string; value: string }>('SELECT key, value FROM user_data WHERE user_id = ?', s.user_id);
  const data: Record<string, string> = {};
  for (const r of rows) data[r.key] = r.value;
  res.json({ data });
});

api.put('/data/:key', requireUnlock, (req, res) => {
  const s = res.locals.session as Session;
  const key = req.params.key;
  if (!KEY_RE.test(key)) return fail(res, 400, 'Bad key');
  if (!req.body || !('value' in req.body)) return fail(res, 400, 'Missing value');
  const value = JSON.stringify(req.body.value);
  if (value === undefined || value.length > MAX_VALUE) return fail(res, 413, 'That is too big to save');
  const count = q.get<{ c: number }>('SELECT COUNT(*) AS c FROM user_data WHERE user_id = ?', s.user_id)!.c;
  const has = q.get('SELECT 1 FROM user_data WHERE user_id = ? AND key = ?', s.user_id, key);
  if (!has && count >= 60) return fail(res, 400, 'Too many saved items');
  q.run(
    'INSERT INTO user_data (user_id, key, value, updated_at) VALUES (?, ?, ?, ?) ON CONFLICT(user_id, key) DO UPDATE SET value = excluded.value, updated_at = excluded.updated_at',
    s.user_id, key, value, Date.now());
  res.json({ ok: true });
});

// ---------- delete my account ----------

api.post('/account/delete-code', requireUnlock, async (_req, res) => {
  const s = res.locals.session as Session;
  try {
    const r = await issueCode(getUser(s.user_id)!, 'delete');
    if (r.wait) return fail(res, 429, `Wait ${r.wait} seconds before asking for another code`, { retryAfter: r.wait });
  } catch {
    return fail(res, 502, "Couldn't send the code. Try again in a moment");
  }
  res.json({ ok: true, resendAfter: RESEND_AFTER });
});

api.delete('/account', requireUnlock, (req, res) => {
  const s = res.locals.session as Session;
  const r = checkCode(getUser(s.user_id)!, 'delete', req.body?.code);
  if (!r.ok) return fail(res, r.status, r.error, r.extra);
  q.run('DELETE FROM users WHERE id = ?', s.user_id); // devices, codes, sessions and data go with it
  res.json({ ok: true });
});

// ---------- test mailbox (only when no real email is set up) ----------

if (mailIsDev && process.env.NODE_ENV !== 'production') {
  api.get('/dev/mailbox', (req, res) => {
    const to = cleanEmail(String(req.query.email || ''));
    res.json({ messages: devMailbox.filter((m) => m.to === to).reverse() });
  });
}

api.use((_req, res) => fail(res, 404, 'Not found'));
api.use((err: unknown, _req: Request, res: Response, _next: NextFunction) => {
  console.error(err);
  fail(res, 500, 'Something went wrong');
});
