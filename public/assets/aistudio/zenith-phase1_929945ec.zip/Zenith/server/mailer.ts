import nodemailer from 'nodemailer';

export interface DevMail {
  to: string;
  subject: string;
  text: string;
  at: number;
}

// With no SMTP settings, mail goes to a fake mailbox in memory and the console.
// That is only for testing on your own computer.
export const devMailbox: DevMail[] = [];
export const mailIsDev = !process.env.SMTP_HOST;

const transport = mailIsDev
  ? null
  : nodemailer.createTransport({
      host: process.env.SMTP_HOST,
      port: Number(process.env.SMTP_PORT || 587),
      secure: Number(process.env.SMTP_PORT || 587) === 465,
      auth: process.env.SMTP_USER ? { user: process.env.SMTP_USER, pass: process.env.SMTP_PASS } : undefined,
    });

export async function sendMail(to: string, subject: string, text: string): Promise<void> {
  if (transport) {
    await transport.sendMail({ from: process.env.MAIL_FROM || process.env.SMTP_USER, to, subject, text });
    return;
  }
  devMailbox.push({ to, subject, text, at: Date.now() });
  if (devMailbox.length > 200) devMailbox.shift();
  console.log(`[fake mailbox] to=${to} | ${subject}\n${text}\n`);
}
