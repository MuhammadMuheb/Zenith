import { DatabaseSync } from 'node:sqlite';
import fs from 'node:fs';
import path from 'node:path';
import crypto from 'node:crypto';

const file = process.env.DATABASE_PATH || path.join(process.cwd(), 'server', 'data', 'zenith.db');
fs.mkdirSync(path.dirname(file), { recursive: true });

export const db = new DatabaseSync(file);
db.exec('PRAGMA journal_mode = WAL;');
db.exec('PRAGMA foreign_keys = ON;');

db.exec(`
CREATE TABLE IF NOT EXISTS meta (
  key TEXT PRIMARY KEY,
  value TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS users (
  id TEXT PRIMARY KEY,
  name TEXT NOT NULL,
  email TEXT NOT NULL UNIQUE,
  pass_hash TEXT NOT NULL,
  verified INTEGER NOT NULL DEFAULT 0,
  created_at INTEGER NOT NULL
);
CREATE TABLE IF NOT EXISTS devices (
  id TEXT NOT NULL,
  user_id TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  pin_hash TEXT,
  pin_salt TEXT,
  pin_fails INTEGER NOT NULL DEFAULT 0,
  locked_until INTEGER NOT NULL DEFAULT 0,
  last_used INTEGER NOT NULL,
  PRIMARY KEY (id, user_id)
);
CREATE TABLE IF NOT EXISTS codes (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  user_id TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  kind TEXT NOT NULL,
  code_hash TEXT NOT NULL,
  expires_at INTEGER NOT NULL,
  tries_left INTEGER NOT NULL,
  used INTEGER NOT NULL DEFAULT 0,
  created_at INTEGER NOT NULL
);
CREATE TABLE IF NOT EXISTS sessions (
  token_hash TEXT PRIMARY KEY,
  user_id TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  device_id TEXT NOT NULL,
  unlock_hash TEXT,
  unlock_expires INTEGER NOT NULL DEFAULT 0,
  expires_at INTEGER NOT NULL,
  created_at INTEGER NOT NULL
);
CREATE TABLE IF NOT EXISTS user_data (
  user_id TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  key TEXT NOT NULL,
  value TEXT NOT NULL,
  updated_at INTEGER NOT NULL,
  PRIMARY KEY (user_id, key)
);
`);

type Param = string | number | null;

export const q = {
  get<T>(sql: string, ...params: Param[]): T | undefined {
    return db.prepare(sql).get(...params) as T | undefined;
  },
  all<T>(sql: string, ...params: Param[]): T[] {
    return db.prepare(sql).all(...params) as T[];
  },
  run(sql: string, ...params: Param[]): void {
    db.prepare(sql).run(...params);
  },
};

function loadSecret(): string {
  if (process.env.SERVER_SECRET) return process.env.SERVER_SECRET;
  const row = q.get<{ value: string }>('SELECT value FROM meta WHERE key = ?', 'server_secret');
  if (row) return row.value;
  const made = crypto.randomBytes(32).toString('hex');
  q.run('INSERT INTO meta (key, value) VALUES (?, ?)', 'server_secret', made);
  return made;
}

export const SERVER_SECRET = loadSecret();
